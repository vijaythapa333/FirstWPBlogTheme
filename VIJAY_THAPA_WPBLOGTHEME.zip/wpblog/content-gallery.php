<!--Post Format Gallery Starts Here-->
    <div class="gallery">
        <h2><?php the_title(); ?></h2>
        <?php the_content(); ?>
    </div>
<!--Post Format Gallery Ends Here-->