<!--Post Format Aside Starts Here-->
    <div class="aside">
        <div class="wrapper">
            <p class="mini-meta"><?php the_author(); ?> @ <?php the_time('F jS, Y'); ?></p>
            <?php the_content(); ?>
        </div>
    </div>
<!--Post Format Aside Ends Here-->