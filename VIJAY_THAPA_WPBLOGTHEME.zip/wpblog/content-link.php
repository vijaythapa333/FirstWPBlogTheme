        <!--Post Format Link Starts Here-->
        <div class="link">
            <div class="wrapper">
                <a href="<?php echo get_the_content(); ?>" target="_blank"><h1><?php the_title(); ?></h1></a>
            </div>
        </div>
        <!--Post Format Link Ends Here-->