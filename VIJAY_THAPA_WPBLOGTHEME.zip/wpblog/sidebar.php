<!--Sidebar Starts Here-->
<div class="side-bar">

    <!--Sidebar Box Starts Here-->
    
        <div class="box">
            <?php dynamic_sidebar('sidebar1'); ?> <!--Writing the id value inside the dynamic_sidebar function-->
        </div>
    <!--Sidebar Box Ends Here-->

    <!--Sidebar Box Starts Here-->
        <div class="box">
            <?php dynamic_sidebar('sidebar2'); ?>
        </div>
        
    <!--Sidebar Box Ends Here-->

    <!--Sidebar Box Starts Here-->
        <div class="box">
            <?php dynamic_sidebar('sidebar3'); ?>
        </div>
        
    <!--Sidebar Box Ends Here-->

    <!--Sidebar Box Starts Here-->
        <div class="box">
            <?php dynamic_sidebar('sidebar4'); ?>
        </div>
        
    <!--Sidebar Box Ends Here-->
</div>
<!--Sidebar Ends Here-->